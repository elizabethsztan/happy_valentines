"""
Happy Valentines - A package to generate daily love poems using GPT-3.5
"""

from .main import LovePoetry

__version__ = "0.1.0"
__all__ = ["LovePoetry"]